package com.anime.dao;

import java.util.List;

import com.anime.entity.Anime;

public interface IAnime {
	
	 Anime findOne(final long id);

	 List<Anime> findAll();

	 void create(final Anime entity);

	 Anime update(final Anime entity);

	 void delete(final Anime entity);

	 void deleteById(final long id);
}	
