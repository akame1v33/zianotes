package com.anime.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.anime.entity.Anime;

@Repository("animeDao")
public class AnimeDao implements IAnime {
	
	@PersistenceContext	
	private EntityManager entityManager;
	
	private Class<Anime> clazz = Anime.class;

	@Override
	public Anime findOne(long id) {
		return (Anime) entityManager.find(clazz, id);
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Anime> findAll() {
		
		return entityManager.createQuery("from " + clazz.getName()).getResultList();
	}

	@Override
	public void create(Anime entity) {
		entityManager.persist(entity);
	}

	@Override
	public Anime update(Anime entity) {
		return (Anime) entityManager.merge(entity);
	}

	@Override
	public void delete(Anime entity) {
		entityManager.remove( entityManager.contains(entity) ? entity : entityManager.merge(entity) );
	}

	@Override
	public void deleteById(long id) {
		delete(findOne(id));
	}	
	
	
}
