package com.anime.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.anime.dao.IAnime;
import com.anime.entity.Anime;

@Service("animeService")
@Transactional
public class AnimeService implements IAnime {
	
	@Autowired
	@Qualifier("animeDao")
	private IAnime dao;
		

	@Override
	public Anime findOne(long id) {
		return dao.findOne(id);
	}

	@Override
	public List<Anime> findAll() {
		
		return dao.findAll();
	}

	@Override
	public void create(Anime entity) {
		dao.create(entity);
	}

	@Override
	public Anime update(Anime entity) {
		return dao.update(entity);
	}

	@Override
	public void delete(Anime entity) {
		dao.delete(entity);
		
	}

	@Override
	public void deleteById(long id) {
		// TODO Auto-generated method stub
		dao.deleteById(id);
	}
	
}
