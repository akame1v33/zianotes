package com.anime;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.anime.dao.IAnime;
import com.anime.entity.Anime;



@SpringBootApplication
public class App implements CommandLineRunner {
	public static void main(String args[]) 	 {
		SpringApplication.run(App.class, args);
	}

	
	@Autowired
	@Qualifier("animeService")
	private IAnime service;
	
	@Override
	public void run(String... args) throws Exception {
		
		System.out.println("******* Anime App **************");
		Anime anime = new Anime();
		anime.setDescription("EXCITING!");
		anime.setTitle("B:The Beginning");
		
		service.create(anime);
		
//		anime = service.findOne(1);
		
//		anime.setTitle("ONE PIECE");
		
//		service.update(anime);
		
	}
}
