package com.listener;

public interface AddListener {
	public Object beforeAdd(String value);
}
