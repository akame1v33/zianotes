//package com.pmti.triu.repository.base;
//
//import java.util.List;
//
//import javax.persistence.EntityManager;
//import javax.persistence.PersistenceContext;
//import javax.persistence.TypedQuery;
//import javax.transaction.Transactional;
//
//import org.hibernate.Session;
//
//import com.pmti.triu.util.ReflectUtil;
//
//
//
//@Transactional
//public abstract class AbstractRepositoryUnderConstruction<T> {
//	
//	@PersistenceContext	
//	private EntityManager em;
//	
//	protected void persist(T entity) {
//		getSession().persist(entity);
//		
////		getSession().save(entity);
////		getSession().sa
//	}
//	
//	protected void update(T entity) {
//		getSession().update(entity);
//	}
//	
//
////	@SuppressWarnings("unchecked")
////	public T findOne(String id) {
////		return (T) getSession().find( ReflectUtil.getGenericClass(this.getClass()) , id);
////	}
////	
////	protected TypedQuery<Object[]> query(String queryString) {
////		return getSession().createQuery(queryString, Object[].class);
////	}
////	
////	protected List<? extends Object[]> queryList(String queryString){
////		return getSession().createQuery(queryString, Object[].class).getResultList();
////	}
////	
////	@SuppressWarnings("unchecked")
////	protected <R> List<R> queryTypedList(String queryString) {
////		return (List<R>) getSession().createQuery(queryString, ReflectUtil.getGenericClass(this.getClass())).getResultList();
////	}
//	
//	protected Session getSession() {
//		return em.unwrap(Session.class);
//	}
//	
//}
