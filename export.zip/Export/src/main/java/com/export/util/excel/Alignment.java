package com.export.util.excel;

import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.VerticalAlignment;
import org.springframework.stereotype.Component;

public class Alignment {
		private HorizontalAlignment horizontalAlignment;
		private VerticalAlignment verticalAlignment;

		public Alignment(HorizontalAlignment horizontalAlignment, VerticalAlignment verticalAlignment) {
			super();
			this.horizontalAlignment = horizontalAlignment;
			this.verticalAlignment = verticalAlignment;
		}
	
		public Alignment() {
			super();
		}

		public HorizontalAlignment getHorizontalAlignment() {
			return horizontalAlignment;
		}

		public void setHorizontalAlignment(HorizontalAlignment horizontalAlignment) {
			this.horizontalAlignment = horizontalAlignment;
		}

		public VerticalAlignment getVerticalAlignment() {
			return verticalAlignment;
		}

		public void setVerticalAlignment(VerticalAlignment verticalAlignment) {
			this.verticalAlignment = verticalAlignment;
		}
		
		
	}