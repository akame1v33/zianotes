package com.export.util.excel;

import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.Workbook;


public final class FontUtil {
	private FontUtil() {}
	
	public static Font createFont(String fontName, int fontSize, boolean isBold,  Workbook workBook ) {
		Font font = workBook.createFont();
		
		font.setFontName(fontName);
		font.setBold(isBold);
		font.setFontHeightInPoints(  (short) fontSize );
		return font;
	}
}
