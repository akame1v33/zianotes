package com.export.util.excel;

import org.apache.poi.ss.usermodel.BorderStyle;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.ss.util.RegionUtil;

public final class BorderUtil {
	private BorderUtil() {}
	
	
	
	public static void setBorder(BorderStyle style, CellRangeAddress region , Sheet sheet) {
    	RegionUtil.setBorderBottom(BorderStyle.THIN, region, sheet);
    	RegionUtil.setBorderTop(BorderStyle.THIN, region, sheet);
    	RegionUtil.setBorderRight(BorderStyle.THIN, region, sheet);
    	RegionUtil.setBorderLeft(BorderStyle.THIN, region, sheet);
	}
	
	public static CellStyle setBorder(CellStyle cellStyle, BorderStyle borderStyle) {
		 cellStyle.setBorderBottom(borderStyle);
	     cellStyle.setBorderTop(borderStyle);
	     cellStyle.setBorderRight(borderStyle);
	     cellStyle.setBorderLeft(borderStyle);
	     return cellStyle;
	}
	
}
