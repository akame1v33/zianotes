package com.export.util.excel;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Row;

public final class CellUtil {
	private CellUtil() {}
	
	public static Cell createCell(String value, Row row, int column, CellStyle cellStyle) {
//		Workbook wb = row.getSheet().getWorkbook();
		Cell cell = row.createCell(column);
	    cell.setCellValue(value);
	    cell.setCellStyle(cellStyle); 
	    
	    
	    
//	    System.out.print(value + " = "+ cellStyle.getBorderBottomEnum() +" , ");
	    return cell;
	}
	public static Cell createCell(Row row, int column, CellStyle cellStyle) {
		Cell cell = row.createCell(column);
		cell.setCellStyle(cellStyle);
	    cell.setCellValue("");
	    return cell;
	}
	
}
