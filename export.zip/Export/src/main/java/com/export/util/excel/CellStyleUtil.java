package com.export.util.excel;

import org.apache.poi.ss.usermodel.BorderStyle;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.Workbook;

public final class CellStyleUtil {
	private CellStyleUtil() {}
	
	
	public static CellStyle createStyle(Font font, Alignment alignment, BorderStyle borderStyle,  Workbook workbook) {

	 
	        CellStyle cellStyle = workbook.createCellStyle();
	        
	        //font
	       
	        //alignment
	        cellStyle.setAlignment(alignment.getHorizontalAlignment());
	        cellStyle.setVerticalAlignment(alignment.getVerticalAlignment());
	        
	        //border
	        cellStyle.setBorderBottom(borderStyle);
	        cellStyle.setBorderTop(borderStyle);
	        cellStyle.setBorderRight(borderStyle);
	        cellStyle.setBorderLeft(borderStyle);

	        cellStyle.setFont(font);
	        return cellStyle;
	}
	
	public static CellStyle createStyle(BorderStyle borderStyle,  Workbook workbook) {

		 
        CellStyle cellStyle = workbook.createCellStyle();
        
        //border
        cellStyle.setBorderBottom( borderStyle);
        cellStyle.setBorderTop(borderStyle);
        cellStyle.setBorderRight(borderStyle);
        cellStyle.setBorderLeft(borderStyle);

        
        return cellStyle;
	}
}
