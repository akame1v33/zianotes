package com.export.util.excel;

import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.VerticalAlignment;

public final class AlignmentUtil {
	private AlignmentUtil() {}
	
	
	public static Alignment upperLeft() {
//		Horizontal
		return new Alignment(HorizontalAlignment.LEFT, VerticalAlignment.TOP);
	}
	public static Alignment upperRight() {
		return new Alignment(HorizontalAlignment.RIGHT, VerticalAlignment.TOP);
	}
	public static Alignment center() {
		return new Alignment(HorizontalAlignment.CENTER, VerticalAlignment.CENTER);
	}
}
