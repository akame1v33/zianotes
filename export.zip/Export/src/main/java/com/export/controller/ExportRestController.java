package com.export.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.export.entity.ExportModel;
import com.export.service.DataService;
import com.export.service.ExcelService;
import com.export.service.PdfService;

@RestController
public class ExportRestController {
	
	@Autowired
	ExcelService excelService;
	
	@Autowired
	PdfService pdfService;
	
	@Autowired
	DataService dataService;
	 @RequestMapping(value="/**", method= RequestMethod.GET)
	 public void e(HttpServletRequest request, HttpServletResponse response) throws Exception {
		 
		 excelService.generate(dataService.getData(), request, response);
	 }
	 @RequestMapping(value="/export", method= RequestMethod.GET)
	 public void export(HttpServletRequest request, HttpServletResponse response) throws Exception {
		 
		 excelService.generate(dataService.getData(), request, response);
	 }
	 
	 @CrossOrigin
	 @RequestMapping(value="/export", method= RequestMethod.POST)
	 public void exportx(@RequestBody ExportModel exportModel, HttpServletRequest request, HttpServletResponse response) throws Exception {
		 System.out.println("WEW!!! POST");
		 excelService.generate(dataService.getData(), request, response);
	 }
}
