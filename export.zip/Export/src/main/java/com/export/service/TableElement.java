package com.export.service;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.export.entity.ExportModel;

public interface TableElement<T, M> {
	
	void addHeader( T table);
	
	void addBody( T table, Iterable<M> listOfModel);
	
	default <P extends ExportModel>	 void generate(P object, HttpServletRequest request, HttpServletResponse response) {
		
	}
}
