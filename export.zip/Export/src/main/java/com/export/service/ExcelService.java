package com.export.service;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.ss.usermodel.BorderStyle;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.util.CellRangeAddress;
import org.springframework.stereotype.Service;
import org.springframework.web.servlet.view.document.AbstractXlsView;

import com.export.entity.ExportModel;
import com.export.util.excel.Alignment;
import com.export.util.excel.AlignmentUtil;
import com.export.util.excel.BorderUtil;
import com.export.util.excel.CellStyleUtil;
import com.export.util.excel.CellUtil;
import com.export.util.excel.FontUtil;

@Service
public class ExcelService extends AbstractXlsView {
	
	
//	private CellStyle cellStyle;
	
	private int currentRow = 0;
	
	private Sheet sheet;
	private Workbook workbook;
	private Font boldFont;
	private CellStyle headerStyle;
	private CellStyle emptyStyle;
	
	
	
	private final int COLUMN_DYNAMIC_SIZE = 2;
	private final int PRE_COLUMN_SIZE = 1;//1 for change column
	
	private int maxColumn = PRE_COLUMN_SIZE;
	@SuppressWarnings("unchecked")
	@Override
	protected void buildExcelDocument(Map<String, Object> model, Workbook workbook, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		
		String fileName = "my-xls-file";
		this.currentRow = 0;
		this.workbook = workbook;	
		response.setHeader("Content-Disposition", "attachment; filename=\" "+fileName+" .xls\"");			

		
		List<Object[]> listOfModel = (List<Object[]>) model.get("listOfModel");
		List<String> years	= (List<String>) model.get("years");
		
		sheet = workbook.createSheet("Port Origin");
        sheet.setDefaultColumnWidth(25);
        sheet.setDefaultRowHeightInPoints((float) 19.00);
        sheet.setZoom(75);
        
        
        boldFont = FontUtil.createFont("Calibri", 11, true, this.workbook);
        
//        rowStyle = CellStyleUtil.createStyle( lightFont , align, BorderStyle.THIN, workbook);
        headerStyle = CellStyleUtil.createStyle( boldFont , AlignmentUtil.center(), BorderStyle.THIN, workbook);
        emptyStyle =  CellStyleUtil.createStyle(BorderStyle.THIN, workbook);
        
        List<String> preColumns = getRelevantPreColumns("MARKET") ;
        maxColumn += (preColumns.size() + (years.size() * 2 )  );
        
        
        addHeader( preColumns , years );
        addBody(listOfModel , preColumns);
 
       
	}
	
	
	private void addHeader(List<String> preColumns, List<String> years) {
		final int size = preColumns.size();
		
		for( int i = 0; i<preColumns.size(); i++) {
			CellRangeAddress region = new CellRangeAddress(0,1,i,i);
			sheet.addMergedRegion( region );
		}   
		
		createRow( (Row row) -> {
        	Alignment align = AlignmentUtil.center();
        	int column = 0;
        	for (String preColumnName : preColumns) {
        		CellUtil.createCell(preColumnName, row, column, headerStyle);
        		column+=1;
			}
        	column = preColumns.size();
            for (String year : years) {
            	 sheet.addMergedRegion(new CellRangeAddress(0,0, column, (column+1)  ) );
                 CellUtil.createCell(year, row, column, headerStyle);
                 column+=2;
			}
            
            sheet.addMergedRegion(new CellRangeAddress(0, 1, column, column  ) );
            CellUtil.createCell("CHANGE", row, column, headerStyle);
        });
//        ****row 1
		createRow( row-> {
        	int column = COLUMN_DYNAMIC_SIZE;
        	for (String year : years) {
        		 CellUtil.createCell(row, 0, 			emptyStyle );
        		 CellUtil.createCell(row, 1,  			emptyStyle );
                 CellUtil.createCell("VALUE",  row, column, 		headerStyle );
                 CellUtil.createCell("SHARE%", row, (column+1), 	headerStyle );
                 column+=2;
        	}
        	CellUtil.createCell(row, column, emptyStyle );
        });
		
		
       	
		createBlankRow();

       	
       	
		createRow( row -> {
			for(int i = 0; i<maxColumn; i++) {
				if( i == (size-1) ) {
					CellUtil.createCell("TOTAL PHL EXPORTS", row,i, headerStyle);
				} else {
					CellUtil.createCell(row, i, emptyStyle );
				}
			}
        	
        });
        
		createBlankRow();
		
		///add border to merge column/row
		addBorderToMergeCell(preColumns);
       
	}
	

	private void addBody(Iterable<Object[]> listOfModel, List<String> preColumns) {
		// TODO Auto-generated method stub
		int yearLength = preColumns.size();
//		Font light =  ;
		
		for (Object[] rowObject : listOfModel) {
			Font font = FontUtil.createFont("Calibri", 11, false, workbook);
			createRow( (row) -> {
				int column = 0;
				for (Object colObject : rowObject) {
					Alignment align =  AlignmentUtil.upperLeft();
					if( column > (yearLength-1)  ) {
						align =  AlignmentUtil.upperRight();
					}				
					
					CellStyle style = CellStyleUtil.createStyle( font , align, BorderStyle.THIN, workbook);
					CellUtil.createCell( (String) colObject , row, column, style);
					
					column+=1;
				}
	        });

		}	
	}
	

	
	public void generate(ExportModel exportModel, HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub

		Map<String, Object> model = new HashMap<String, Object>();
		if( exportModel != null ) {
			model.put("listOfModel", exportModel.getListOfModel());
			model.put("total", exportModel.getTotal());
			model.put("years", exportModel.getYears());
		}
		
		try {
			this.renderMergedOutputModel(model, request, response);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	private void createCell(Row row, int column, Alignment align, String value, boolean bold) {
        Cell cell = row.createCell(column);
        cell.setCellValue(value);
        Font font = workbook.createFont();
        font.setBold(bold);
        font.setFontName("Calibri");
       
        font.setFontHeightInPoints( (short) 11 );
        
        CellStyle cellStyle = workbook.createCellStyle();
        cellStyle.setAlignment(align.getHorizontalAlignment());
        cellStyle.setVerticalAlignment(align.getVerticalAlignment());
//        cellStyle.setIndention((short)4);
        
      
        BorderStyle border = BorderStyle.THIN;
        cellStyle.setBorderBottom( border);
        cellStyle.setBorderTop(border);
        cellStyle.setBorderRight(border);
        cellStyle.setBorderLeft(border);
        cellStyle.setFont(font);
        
        cell.setCellStyle(cellStyle);
    }


	private Row createRow(Consumer<Row> consumer) {
		 Row row = sheet.createRow(currentRow);
		 if( consumer != null ) {
			 consumer.accept(row);
		 }
		 currentRow++;	
		 return row;
	}
	
	private void streamColumns(Consumer<Integer> consumer) {
		for(int i = 0; i<maxColumn; i++) {
			consumer.accept(i);
		}
	}
	
	
	private void addBorderToMergeCell(List<String> columns) {
		for( int i = 0; i<columns.size(); i++) {
    		CellRangeAddress region = new CellRangeAddress(0,1,i,i);
    		BorderUtil.setBorder(BorderStyle.THIN, region, sheet);
		}
	} 
	
	
	private List<String> getRelevantPreColumns(String reportType) {
		switch(reportType.toString()) {
		case "PORT_OF_ORIGIN":
			return Arrays.asList("REGION","PORT");
		case "MARKET":
			return Arrays.asList("MARKET");
		case "REGIONAL_BLOC":
			return Arrays.asList("MARKET");
		case "PHL_EXPORT_DIGIT":
			return Arrays.asList("RANK","6DIGIT","DESCRIPTION");
		default:
			throw new IllegalArgumentException("Invalid Report type");
		}
	}

	private void createBlankRow() {
		createRow( row -> {
       		streamColumns( i -> {
       			CellUtil.createCell(row, i,  CellStyleUtil.createStyle(BorderStyle.THIN, workbook) );
       		});
        });
	}
	
}
