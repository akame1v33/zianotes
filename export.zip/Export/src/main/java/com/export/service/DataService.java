package com.export.service;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.export.Utils;
import com.export.entity.ExportModel;

@Service
public class DataService {
	
	@Autowired
	private Utils utils;
	
	private final String candidateChars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";

    private final String candidateNum = "0123456789";
	
	public ExportModel getData(){
		int size = 50;
		List<Object[]> objects = IntStream.rangeClosed(0, size)
				.mapToObj( (i) -> {
					Object[] obj = new Object[7];
					for (int idx = 0; idx<7; idx++) {
						obj[idx] = utils.generateRandomChars(candidateChars, 18); 
					}
					return obj;
				}).collect( Collectors.toList() );
		
		
		List<String> years = IntStream.rangeClosed(2010,2011)
				.mapToObj( (i) -> {
		
					return i+"";
				}).collect( Collectors.toList() );
				
		ExportModel model = new ExportModel();
		model.setListOfModel(objects);
		model.setYears(years);
		return model;
	}
}
