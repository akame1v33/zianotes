package com.export.service;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Service;

import com.export.view.AbstractPdfView;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

@Service
public class PdfService extends AbstractPdfView implements TableElement<PdfPTable, Object[]> {

	
	private PdfPCell pdfPCell;
	private Font font;
	private List<Object[]> objects;
	
	@Override
	protected void buildPdfDocument(Map<String, Object> model, Document document, PdfWriter writer,
			HttpServletRequest request, HttpServletResponse response) throws Exception {
		
		
		response.setHeader("Content-Disposition", "attachment; filename=\"my-pdf-file.pdf\"");
        document.add(new Paragraph("Generated Users " + LocalDate.now()));

        PdfPTable table = new PdfPTable(2);
        table.setWidthPercentage(100.0f);
        table.setSpacingBefore(10);

        // define font for table header row
        font = FontFactory.getFont(FontFactory.TIMES);
        font.setColor(BaseColor.WHITE);

        // define table header cell
        pdfPCell = new PdfPCell();
        pdfPCell.setBackgroundColor(BaseColor.DARK_GRAY);
        pdfPCell.setPadding(5);
        
        
        addHeader(table);
        // write table header
       
//        addBody(table, objects);
//	    table.addCell("@3232323232");
//        table.addCell("@3232323232");
        
        
        document.add(table);
		
	}


//	public PdfPTable addHeader(PdfPTable table) {
//		pdfPCell.setPhrase(new Phrase("First Name", font));
//	    table.addCell(pdfPCell);
//
//	    pdfPCell.setPhrase(new Phrase("Last Name", font));
//	    table.addCell(pdfPCell);
//	    
//	    return table;
//	}
//
//	
//	public void  addBody(PdfPTable table, Iterable<Object[]> listOfModel) {
//		// TODO Auto-generated method stub
//		
//	}
//
//	
	public void generate(Iterable<Object[]> listOfModels, HttpServletRequest request, HttpServletResponse response) {
		Map<String, Object> model = new HashMap<String, Object>();
		model.put("listOfModel", listOfModels);
		try {
			this.renderMergedOutputModel(model, request, response);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}


	@Override
	public void addHeader(PdfPTable table) {
		// TODO Auto-generated method stub
		pdfPCell.setPhrase(new Phrase("First Name", font));
	    table.addCell(pdfPCell);
	    pdfPCell.setPhrase(new Phrase("Last Name", font));
	    table.addCell(pdfPCell);
	}


	@Override
	public void addBody(PdfPTable table, Iterable<Object[]> listOfModel) {
		// TODO Auto-generated method stub
		
	}

}
