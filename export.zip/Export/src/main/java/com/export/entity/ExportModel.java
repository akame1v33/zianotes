package com.export.entity;

import java.util.List;

public class ExportModel {
	
	private String reportType;
	
	private List<String> years;
	
	private List<Object[]> listOfModel;
	
	private List<Object[]> total;

	@Override
	public String toString() {
		return "ExportModel [years=" + years + ", listOfModel=" + listOfModel + ", total=" + total + "]";
	}

	
	public String getReportType() {
		return reportType;
	}


	public void setReportType(String reportType) {
		this.reportType = reportType;
	}


	public List<String> getYears() {
		return years;
	}

	public void setYears(List<String> years) {
		this.years = years;
	}

	public List<Object[]> getListOfModel() {
		return listOfModel;
	}

	public void setListOfModel(List<Object[]> listOfModel) {
		this.listOfModel = listOfModel;
	}

	public List<Object[]> getTotal() {
		return total;
	}

	public void setTotal(List<Object[]> total) {
		this.total = total;
	}

	public ExportModel() {
		super();
	}
	
	
}
