package com.inter;

import javax.persistence.PostLoad;
import javax.persistence.PostPersist;
import javax.persistence.PrePersist;

import com.app.Anime;

public class SampleListener {
	
	@PrePersist
	public void prePersist(Anime anime) {
		System.out.println("PRE PERSIST: " + anime.getTitle());
	}

	
	@PostPersist
	public void postPersist(Anime anime) {
		System.out.println("POST PERSIST: " + anime.getTitle());
	}
	
	@PostLoad
	public void postLoad(Anime anime) {
		System.out.println("Post Load: "+anime.toString());
		
	}
	

	
}
