package com.inter;

import java.text.ParseException;
import java.text.SimpleDateFormat;

import javax.persistence.PrePersist;

public class CreatedAtListener {
	
	
	@PrePersist
	public void setCreatedAt(final Creatable entity) {
		SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
		try {
			entity.setCreatedAt( sdf.parse("06/15/1992") );
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}	
