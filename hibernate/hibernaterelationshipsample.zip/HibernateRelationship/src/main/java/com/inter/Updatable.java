package com.inter;

public interface Updatable {

}
