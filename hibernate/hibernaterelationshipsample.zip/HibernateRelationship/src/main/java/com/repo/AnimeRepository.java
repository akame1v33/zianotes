package com.repo;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.app.AnimeExtreme;

@Repository
public interface AnimeRepository extends CrudRepository<AnimeExtreme, String> {

	
//	@Query("SELECT a FROM Anime")
//	Optional<List<Anime>> findAnime();
}
