package com.repo;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.app.AnimeDetail;

@Repository
public interface AnimeDetailRepository extends CrudRepository<AnimeDetail, String>  {


	
	@Query("SELECT a FROM AnimeDetail a WHERE id =11")
	Optional<List<AnimeDetail>> findAnimeDetails();
}
