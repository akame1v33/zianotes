package com.app;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.inter.BaseEntity;
import com.inter.Creatable;
import com.inter.CreatedAtListener;
@EntityListeners({
	CreatedAtListener.class,
//	SampleListener.class	
})
@Entity
@Table(name="ANIME")
//@AttributeOverride( name="createdAt", column = @Column(name="created_at") )
public class Anime  extends BaseEntity implements Creatable {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long anime_id;
	
	
	private String title;
	
	
	@ManyToMany
	@JoinTable(
			name="anime_certification",
			joinColumns = {@JoinColumn(name = "ANIME_ID")},
			inverseJoinColumns = {@JoinColumn(name = "CERTIFICATE_ID")}
	)
	List<Certification> certifications = new ArrayList<Certification>();
	
	
	
	public List<Certification> getCertifications() {
		return certifications;
	}
	public void setCertifications(List<Certification> certifications) {
		this.certifications = certifications;
	}
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="ID")
	AnimeDetail animeDetail;
	
	@OneToMany(cascade = CascadeType.ALL, mappedBy="anime")
	private List<Movie> movies = new ArrayList<Movie>();
	
	

	public List<Movie> getMovies() {
		return movies;
	}
	public void setMovies(List<Movie> movies) {
		this.movies = movies;
	}
	public AnimeDetail getAnimeDetail() {
		return animeDetail;
	}
	public void setAnimeDetail(AnimeDetail animeDetail) {
		this.animeDetail = animeDetail;
	}
	public long getAnime_id() {
		return anime_id;
	}
	public void setAnime_id(long anime_id) {
		this.anime_id = anime_id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	@Override
	public String toString() {
		return "Anime [id=" + anime_id + ", title=" + title + "]";
	}
	public Anime() {
		super();
	}
	
	
}
