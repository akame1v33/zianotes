package com.app;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

@Entity
@Table(name="ANIME_DETAIL")
public class AnimeDetail implements Serializable {
	
	@Id 
	@GeneratedValue(generator="test")
	@GenericGenerator(name = "test" , strategy = "foreign", parameters = {@Parameter(value = "anime", name = "property")})
	private long anime_id;
	
	
	private String genre;
	
	private String episode;
	
	
//	@OneToOne(cascade = CascadeType.ALL, mappedBy="animeDetail")
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "anime_id")
	private Anime anime;
	
	
	public Anime getAnime() {
		return anime;
	}

	public void setAnime(Anime anime) {
		this.anime = anime;
	}
	
//
	public long getAnime_id() {
		return anime_id;
	}

	public void setAnime_id(long anime_id) {
		this.anime_id = anime_id;
	}



	public String getGenre() {
		return genre;
	}

	public void setGenre(String genre) {
		this.genre = genre;
	}

	public String getEpisode() {
		return episode;
	}

	public void setEpisode(String episode) {
		this.episode = episode;
	}

	@Override
	public String toString() {
		return "AnimeDetail [anime_id= genre=" + genre + ", episode=" + episode + ", animes=" + anime
				+ "]";
	}

	public AnimeDetail(String genre, String episode) {
		super();
		this.genre = genre;
		this.episode = episode;
	}

	public AnimeDetail() {
		super();
	}
	
	
	
	
	
}
