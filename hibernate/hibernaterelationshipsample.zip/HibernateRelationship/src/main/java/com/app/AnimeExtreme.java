package com.app;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name="ANIME")
public class AnimeExtreme {
	
	
	@Id
	@GeneratedValue(strategy= GenerationType.IDENTITY)
	@Column(name="ID")
	private int id;
	
	private String title;
	
	@ManyToMany(cascade = CascadeType.ALL)
    @JoinTable(
            name = "ANIME_CERTIFICATION",
            joinColumns = @JoinColumn(name = "ANIME_ID"),
            inverseJoinColumns = @JoinColumn(name = "CERTIFICATE_ID")
    )
	List<Certification> certifications = new ArrayList<Certification>();
	
	
	public List<Certification> getCertifications() {
		return certifications;
	}

	public void setCertifications(List<Certification> certifications) {
		this.certifications = certifications;
	}

	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}
	
	
}
