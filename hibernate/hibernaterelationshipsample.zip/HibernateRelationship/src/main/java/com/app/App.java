package com.app;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.YearMonth;
import java.util.Calendar;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.MessageSource;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import com.repo.AnimeDetailRepository;
import com.repo.AnimeRepository;
import com.repo.CertificateRepository;
import com.repo.MovieRepository;




@SpringBootApplication
@EnableJpaRepositories("com.repo")
public class App implements CommandLineRunner {
	
	@Autowired
	MessageSource ms;
	
	@Autowired
	AnimeRepository animeRepository;
	
	@Autowired
	MovieRepository movieRepository;
	
	@Autowired
	AnimeDetailRepository animeDetailRepository;
	
	@Autowired
	CertificateRepository certificateRepository;
	
	public static void main(String args[]) {
		SpringApplication.run(App.class, args);
	}

	public int getNumberOfDayInMonth(String date) {
		Calendar c = Calendar.getInstance();
		SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
		int year 		= c.get(Calendar.YEAR) ;
		int month 		= c.get(Calendar.MONTH)+1;
		try {
			c.setTime( sdf.parse(date)  );
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			return 0;
		}

//		YearMonth yearMonthObject = YearMonth.of(year, month);
		return YearMonth.of(year, month).lengthOfMonth();
	}
	@Override
	public void run(String... args) throws Exception {
		///MANY TO ONE
//		Anime anime = new Anime();
//		anime.setTitle("Black Clover Origin");
//		List<Movie> movies = new ArrayList<Movie>();
//		Movie m1 = new Movie();
//		
//		m1.setTitle("Black Clover the movie 1");
//		m1.setAnime(anime);
//		movies.add(m1);
//		Movie m2 = new Movie();
//		m2.setTitle("Green Clover The 9th Sword");
//		m2.setAnime(anime);
//		movies.add(m2);
//		movieRepository.saveAll(movies);
		///MANY TO ONE
		
//		
//		SimpleDateFormat sdf = new SimpleDateFormat("mm/dd/yyyy");
//		
//		Calendar c = new GregorianCalendar();
//		c.setTime( sdf.parse("5/23/2018") );
//		
//		System.out.println( "number of day : "+c.getActualMinimum(Calendar.DAY_OF_MONTH) );
//		
		App app = new App();
		System.out.println( app.getNumberOfDayInMonth("06/23/2018") );
//		Calendar c = Calendar.getInstance();
//		
//		SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
//		
//		c.setTime( sdf.parse("05/23/2018")  );
//
//		int year 		= c.get(Calendar.YEAR) ;
//		int month 		= c.get(Calendar.MONTH)+1;
//
//		
//		System.out.println(  year );
//		System.out.println(   month );
//		YearMonth yearMonthObject = YearMonth.of(year, month);
//		int daysInMonth = yearMonthObject.lengthOfMonth();
//		System.out.println( daysInMonth );
////		YearMonth yearMonthObject = YearMonth.of(i, 2);
//		int daysInMonth = yearMonthObject.lengthOfMonth();
//		System.out.println( sdf.parse("5/23/2018").getDate() );
//		System.out.println( sdf.parse("5/23/2018").get);
//		for(int i = 1992; i<=2019; i++) {
//			YearMonth yearMonthObject = YearMonth.of(i, 2);
//			int daysInMonth = yearMonthObject.lengthOfMonth();
////			System.out.println( daysInMonth );
//		}
		
		
		
//		Certification c1 = new Certification();
//		c1.setCertCode("BH");
//		c1.setDescription("HAPPY");
//		
//		Certification c2 = new Certification();
//		c2.setCertCode("BH");
//		c2.setDescription("SAD");
//		
//		
//		AnimeExtreme a1 = new AnimeExtreme();
//		a1.setTitle("ANO HANA");
//		a1.getCertifications().add(c1);
//		a1.getCertifications().add(c2);
//		
//
//		animeRepository.save(a1);
		
//		certificateRepository.save(c);
		
		
		
//		Anime anime = new Anime();
//		anime.setTitle("No Game No Life");
//		anime.setCreatedAt( new Date() );
//		Movie m1 = new Movie();
//
//		m1.setTitle("No Game No Life:Zero");
//		m1.setAnime(anime);
//		anime.getMovies().add(m1);
//		Movie m2 = new Movie();
//		m2.setTitle("No Game No Life:Re Zero");
//		m2.setAnime(anime);
//		anime.getMovies().add(m2);
//		
//		
//		
////		movieRepository.saveAll(movies);
//		animeRepository.save(anime);
//		for (Anime a : animeRepository.findAll()) {
//			System.out.println(a.toString());
//		}
//		
	}
	
	
	//BOTH SIDES
//	public void oneToOneBiDirectional() {
//		Anime anime = new Anime();
//		anime.setTitle("Nanatsu no tazai");
//		
//		
//		AnimeDetail animeDetail = new AnimeDetail("Fantasy, Fighter","156");
//		
//		animeDetail.setAnime(anime);
//		anime.setAnimeDetail(animeDetail);
//		
//		
//		animeRepository.save(anime);
//	}

}
