package com.app;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name="CERTIFICATION")
public class Certification {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="ID")
	private long id;
	
	@Column(name="CERTCODE")
	private String certCode;
	
	
	private String description;

	@ManyToMany(mappedBy="certifications")
	List<AnimeExtreme> anime = new ArrayList<AnimeExtreme>();
	
	
	
	
	
	public List<AnimeExtreme> getAnime() {
		return anime;
	}

	public void setAnime(List<AnimeExtreme> anime) {
		this.anime = anime;
	}

	
	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}
	
	
	public String getCertCode() {
		return certCode;
	}

	public void setCertCode(String certCode) {
		this.certCode = certCode;
	}
	
	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}
	
	
	
}
