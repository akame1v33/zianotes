package com.pmti.triu.model;

import java.util.Date;

import javax.validation.constraints.NotNull;

import com.pmti.triu.validator.IsValidBirthdate;
//@JsonInclude(Include.NON_NULL)
public class TaxpayerSearch {
	
	@NotNull
	private String tinWithBranchCode;
	
	@NotNull
	private String registeredName;
	
	@NotNull
	private String firstName;
	
	@NotNull
	private String lastName;
	
	@NotNull
	private Date birthDate;
	
	@NotNull
	private Date orgDate;
	
	@NotNull
	private String taxpayerClassificationType;
	
	@NotNull
	private String taxpayerType;
	
	@NotNull
	private String businessName;
	
	
	@NotNull
	private Date createdDate;

	
	public String getTinWithBranchCode() {
		return tinWithBranchCode;
	}

	public void setTinWithBranchCode(String tinWithBranchCode) {
		this.tinWithBranchCode = tinWithBranchCode;
	}

	public String getRegisteredName() {
		return registeredName;
	}

	public void setRegisteredName(String registeredName) {
		this.registeredName = registeredName;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public Date getBirthDate() {
		return birthDate;
	}

	public void setBirthDate(Date birthDate) {
		this.birthDate = birthDate;
	}

	public Date getOrgDate() {
		return orgDate;
	}

	public void setOrgDate(Date orgDate) {
		this.orgDate = orgDate;
	}

	public String getTaxpayerClassificationType() {
		return taxpayerClassificationType;
	}

	public void setTaxpayerClassificationType(String taxpayerClassificationType) {
		this.taxpayerClassificationType = taxpayerClassificationType;
	}

	public String getTaxpayerType() {
		return taxpayerType;
	}

	public void setTaxpayerType(String taxpayerType) {
		this.taxpayerType = taxpayerType;
	}

	public String getBusinessName() {
		return businessName;
	}

	public void setBusinessName(String businessName) {
		this.businessName = businessName;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	@Override
	public String toString() {
		return "TaxpayerSearch [tinWithBranchCode=" + tinWithBranchCode + ", registeredName=" + registeredName
				+ ", firstName=" + firstName + ", lastName=" + lastName + ", birthDate=" + birthDate + ", orgDate="
				+ orgDate + ", taxpayerClassificationType=" + taxpayerClassificationType + ", taxpayerType="
				+ taxpayerType + ", businessName=" + businessName + ", createdDate=" + createdDate + "]";
	}

	public TaxpayerSearch() {
		super();
	}
	
	
//	private Date
}
