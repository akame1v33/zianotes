package com.pmti.triu.config;

import java.sql.SQLException;

import javax.sql.DataSource;
import javax.validation.constraints.NotNull;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import oracle.jdbc.pool.OracleDataSource;
 
@Configuration
public class CebOracleConfiguration {
	
    @Value("${ceb.datasource.username}")
    private String username;
 
    @Value("${ceb.datasource.password}")
    private String password;
 
    @Value("${ceb.datasource.url}")
    private String url;
 
    public void setUsername(String username) {
        this.username = username;
    }
 
    public void setPassword(String password) {
        this.password = password;
    }
 
    public void setUrl(String url) {
        this.url = url;
    }
 
    @Bean
    DataSource dataSource() throws SQLException {
 
        OracleDataSource dataSource = new OracleDataSource();
        System.out.println("username : "+username);
        System.out.println("password : "+password);
        System.out.println("url : "+url);
        dataSource.setUser(username);
        dataSource.setPassword(password);
        dataSource.setURL(url);
        
        
        return dataSource;
    }
}
