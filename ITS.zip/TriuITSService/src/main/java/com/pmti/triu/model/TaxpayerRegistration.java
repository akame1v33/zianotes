package com.pmti.triu.model;

import com.fasterxml.jackson.annotation.JsonProperty;

///this is consumer model
public class TaxpayerRegistration {
	
	
	private Taxpayer taxpayer;
	
	private TaxpayerLocation taxpayerLocation;
	
	private TaxpayerAddresses taxpayerAddress;
	
	private TaxpayertypeDetail taxpayertypeDetail;
	
	private TaxtypeDetail taxtypeDetail;
	
	private Business business;
	
	private Industry industry;
	
	private Phone phone;

	public Taxpayer getTaxpayer() {
		return taxpayer;
	}

	public void setTaxpayer(Taxpayer taxpayer) {
		this.taxpayer = taxpayer;
	}

	public TaxpayerLocation getTaxpayerLocation() {
		return taxpayerLocation;
	}

	public void setTaxpayerLocation(TaxpayerLocation taxpayerLocation) {
		this.taxpayerLocation = taxpayerLocation;
	}

	public TaxpayerAddresses getTaxpayerAddress() {
		return taxpayerAddress;
	}

	public void setTaxpayerAddress(TaxpayerAddresses taxpayerAddress) {
		this.taxpayerAddress = taxpayerAddress;
	}

	public TaxpayertypeDetail getTaxpayertypeDetail() {
		return taxpayertypeDetail;
	}

	public void setTaxpayertypeDetail(TaxpayertypeDetail taxpayertypeDetail) {
		this.taxpayertypeDetail = taxpayertypeDetail;
	}

	public TaxtypeDetail getTaxtypeDetail() {
		return taxtypeDetail;
	}

	public void setTaxtypeDetail(TaxtypeDetail taxtypeDetail) {
		this.taxtypeDetail = taxtypeDetail;
	}

	public Business getBusiness() {
		return business;
	}

	public void setBusiness(Business business) {
		this.business = business;
	}

	public Industry getIndustry() {
		return industry;
	}

	public void setIndustry(Industry industry) {
		this.industry = industry;
	}

	public Phone getPhone() {
		return phone;
	}

	public void setPhone(Phone phone) {
		this.phone = phone;
	}

	public TaxpayerRegistration() {
		super();
	}

	@Override
	public String toString() {
		return "TaxpayerRegistration [taxpayer=" + taxpayer + ", taxpayerLocation=" + taxpayerLocation
				+ ", taxpayerAddress=" + taxpayerAddress + ", taxpayertypeDetail=" + taxpayertypeDetail
				+ ", taxtypeDetail=" + taxtypeDetail + ", business=" + business + ", industry=" + industry + ", phone="
				+ phone + "]";
	}
	
	
	

//	@JsonInclude(Include.NON_NULL)
}
