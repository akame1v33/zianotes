package com.pmti.triu.util;

import java.util.UUID;

public final class GeneratorUtil {
	private GeneratorUtil() {}
	
	public static String generateUUID() {
		return UUID.randomUUID().toString();
	}
}
