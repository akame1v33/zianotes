package com.pmti.triu.util;

import java.util.Locale;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.support.MessageSourceAccessor;
import org.springframework.stereotype.Component;


@Component
public class MessageUtil {
	
	
	@Autowired
    private MessageSource messageSource;

    private MessageSourceAccessor accessor;

    @PostConstruct
    private void init() {
        accessor = new MessageSourceAccessor(messageSource, Locale.ENGLISH);
    }

    public String get(String code) {
//    	System.out.println("Code: "+code);
        return accessor.getMessage(code);
    }
//    public String getExceptionMessage(String code) {
////    	accessor.
//        return accessor.getMessage("exception."+code);
////    	return messageSource.getMessage("exception."+code);
//    }
    public String get(String messageKey, Map<String, String> model) {
    	String rawText = accessor.getMessage(messageKey);
    	
    	
    	for (String key : model.keySet()) {
			String value = model.get(key);
			rawText = rawText.replaceAll( "\\$\\{"+ key +"\\}" , value  );
		}
    	
        return rawText;
    }
}
