package com.pmti.triu.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.pmti.triu.model.base.AbstractModel;

@Entity
@Table(name="REG_PHONES")
public class Phone extends AbstractModel {

	/**
	 * 
	 */
	@Transient
	private static final long serialVersionUID = -1216868824315533933L;
	
	@Id
	@Column(name="TIN")
	private String tin;
	
	@Column(name="BRANCH_CODE")
	private String branchCode;
	
	@Column(name="ADR_CODE")
	private String adrCode;
	
	@Column(name="STATUS_CODE")
	private String statusCode;
	
	@Column(name="CODE")
	private String code;
	
	@Column(name="NUM")
	private String contactNumber;
	
	@Column(name="PROCESS")
	private String process;

	@Override
	public String toString() {
		return "Phone [tin=" + tin + ", branchCode=" + branchCode + ", adrCode=" + adrCode + ", statusCode="
				+ statusCode + ", code=" + code + ", contactNumber=" + contactNumber + ", process=" + process
				+ ", getCreatedDate()=" + getCreatedDate() + ", getCreatedBy()=" + getCreatedBy()
				+ ", getLastModifiedDate()=" + getLastModifiedDate() + ", getLastModifieidBy()=" + getLastModifieidBy()
				+ ", getClass()=" + getClass() + ", hashCode()=" + hashCode() + ", toString()=" + super.toString()
				+ "]";
	}

	public Phone() {
		super();
	}
	
	
}
