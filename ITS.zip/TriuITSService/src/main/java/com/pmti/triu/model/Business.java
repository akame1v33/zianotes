package com.pmti.triu.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.pmti.triu.model.base.AbstractModel;

@Entity
@Table(name="REG_BUSINESS_NAMES")
public class Business extends AbstractModel {
	
	@Id
	@Column(name="TIN")
//	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "INSERT_TaxPaye2_SEQ")
//	@SequenceGenerator(sequenceName = "	OSSEQ_OSUSR_HPY_TAXPAYE2", allocationSize = 1, name = "INSERT_TaxPaye2_SEQ")
	private String tin;
	
	@Column(name="BRANCH_CODE")
	private String branchCode;
	
	@Column(name="TRADE_NAME")
	private String tradeName;
	
	@Column(name="PROCESS")
	private String process;

	public String getTin() {
		return tin;
	}

	public void setTin(String tin) {
		this.tin = tin;
	}

	public String getBranchCode() {
		return branchCode;
	}

	public void setBranchCode(String branchCode) {
		this.branchCode = branchCode;
	}

	public String getTradeName() {
		return tradeName;
	}

	public void setTradeName(String tradeName) {
		this.tradeName = tradeName;
	}

	public String getProcess() {
		return process;
	}

	public void setProcess(String process) {
		this.process = process;
	}

	@Override
	public String toString() {
		return "Business [tin=" + tin + ", branchCode=" + branchCode + ", tradeName=" + tradeName + ", process="
				+ process + ", getCreatedDate()=" + getCreatedDate() + ", getCreatedBy()=" + getCreatedBy()
				+ ", getLastModifiedDate()=" + getLastModifiedDate() + ", getLastModifieidBy()=" + getLastModifieidBy()
				+ "]";
	}

	public Business() {
		super();
	}
	
	
	
}

