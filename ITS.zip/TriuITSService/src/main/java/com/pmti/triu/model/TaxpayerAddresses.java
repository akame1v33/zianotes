package com.pmti.triu.model;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.pmti.triu.model.base.AbstractModel;
import com.pmti.triu.model.base.Address;

@Entity
@Table(name="REG_ADDRESSES")
@AttributeOverrides({
	@AttributeOverride(name="createdDate", 			column = @Column(name="DATE_CREATED")),
	@AttributeOverride(name="createdBy", 			column = @Column(name="CREATED_BY")),
	@AttributeOverride(name="lastModifiedDate", 	column = @Column(name="DATE_MODIFIED")),
	@AttributeOverride(name="lastModifieidBy", 		column = @Column(name="MODIFIED_BY"))
})
public class TaxpayerAddresses extends AbstractModel {
	
	/**
	 * 
	 */
	@Transient
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="TIN")
	private String tin;
	
	@Column(name="BRANCH_CODE")
	private String branchCode;
	
	/**
	 * Residence, Business, Mailing/Postal or Foreign 
	 */
	@Column(name="CODE")
	private String code;
	
	@Column(name="STATUS_CODE")
	private String statusCode;

	@Embedded
	@AttributeOverrides({
		 @AttributeOverride(name="substreet", 		column = @Column(name="SUBSTREET") ),
		 @AttributeOverride(name="street", 			column = @Column(name="STREET") ),
		 @AttributeOverride(name="barangay", 		column = @Column(name="BARANGAY") ),
		 @AttributeOverride(name="district", 		column = @Column(name="DISTRICT") ),
		 @AttributeOverride(name="city", 			column = @Column(name="CITY") ),
		 @AttributeOverride(name="zipCode", 		column = @Column(name="ZIP_CODE") ),
	})
	private Address address;
	
	@Column(name="REGISTER_FLAG")
	private String registerFlag;
	
	@Column(name="MAIL_ROUTE")
	private String mailRoute;
	
	@Column(name="PROCESS")
	private String process;

	public String getTin() {
		return tin;
	}

	public void setTin(String tin) {
		this.tin = tin;
	}

	public String getBranchCode() {
		return branchCode;
	}

	public void setBranchCode(String branchCode) {
		this.branchCode = branchCode;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public String getRegisterFlag() {
		return registerFlag;
	}

	public void setRegisterFlag(String registerFlag) {
		this.registerFlag = registerFlag;
	}

	public String getMailRoute() {
		return mailRoute;
	}

	public void setMailRoute(String mailRoute) {
		this.mailRoute = mailRoute;
	}

	public String getProcess() {
		return process;
	}

	public void setProcess(String process) {
		this.process = process;
	}

	@Override
	public String toString() {
		return "TaxpayerAddresses [tin=" + tin + ", branchCode=" + branchCode + ", code=" + code + ", statusCode="
				+ statusCode + ", address=" + address + ", registerFlag=" + registerFlag + ", mailRoute=" + mailRoute
				+ ", process=" + process + "]";
	}

	public TaxpayerAddresses() {
		super();
	}
	
	
	
	
	
}
