package com.pmti.triu.util;

import java.util.List;

public final class Optional<T> {
	private Optional() {};
	
	private T entity;
	private List<T> entityList;
	
	public T get() {
		return entity;
	}
	
	
	private void set(T entity) {
		this.entity = entity;
	}
	
	public boolean isPresent() {
		if( entity == null ) {
			return false;
		}
		return true;
	}
	public static <T> T empty() {
		Optional optional = new Optional();
		
		optional.set(null);
		return (T) optional;
	}
	public static <T> T of(T entity) {
		Optional optional = new Optional();
		
		optional.set(entity);
		return (T) optional;
	}
//	public static <T> List<T> of(List<T> entity) {
//		
//		return entity;
//	}
}
