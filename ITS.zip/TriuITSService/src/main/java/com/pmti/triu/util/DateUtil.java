package com.pmti.triu.util;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
//import java.time.YearMonth;
import java.util.Calendar;
import java.util.Date;
import java.util.concurrent.TimeUnit;

public final class DateUtil {
	private DateUtil() {}
	public static String getMonth(int monthPos) {
		
		switch( monthPos ) {
		case 1 : return "Jan";
		case 2 : return "Feb";
		case 3 : return "Mar";
		case 4 : return "Apr";
		case 5 : return "May";
		case 6 : return "Jun";
		case 7 : return "Jul";
		case 8 : return "Aug";
		case 9 : return "Sep";
		case 10 : return "Oct";
		case 11 : return "Nov";
		case 12 : return "Dec";
				
		}
//		Calendar.getInstance().get
		return "";
	}
	public static String getPresentDate(final String format) {
		SimpleDateFormat sdf = new SimpleDateFormat(format);
		return sdf.format(new Date());
	}
	public static Timestamp getTimestamp() {
		return new Timestamp( new Date().getTime() );
	}
	
	public static Date parse(String date, String format) throws ParseException {
		SimpleDateFormat sdf = new SimpleDateFormat(format);
		return sdf.parse(date);
	}
	public static String parse(Date date, String format) {
		if( date == null ) {
			return "";
					
		}
		
		return  new SimpleDateFormat(format).format(date);
	}
	
	public static String getCurrentYear() {
		Date now = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy");
		
		return sdf.format(now);
	}
	public static String getCurrentYear(String yearFormat) {
		Date now = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat(yearFormat);
		
		return sdf.format(now);
	}
	public static long getDiffYearFromNow(String date) {
		Date now = new Date();
		Date birthDate = null;
		try {
			birthDate = DateUtil.parse(date, "MMddyyyy");
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		long diffInMillies = now.getTime() - birthDate.getTime();
		long days			= TimeUnit.DAYS.convert(diffInMillies, TimeUnit.MILLISECONDS);
		
		//need to change. leap year is 366days
		return days / 365;
	}
	
//	public static int getNumberOfDayInMonth(String date) {
//		Calendar c = Calendar.getInstance();
//		SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
//		int year 		= 0;
//		int month 		= 0;
//		try {
//			c.setTime( sdf.parse(date)  );
//			year 	= c.get(Calendar.YEAR) ;;
//			month 	= c.get(Calendar.MONTH)+1;
//		} catch (ParseException e) {
//			// TODO Auto-generated catch block
//			return 0;
//		}
//
//		return YearMonth.of(year, month).lengthOfMonth();
//	}
	public static int getMonth(String date) {
		Calendar c = Calendar.getInstance();
		SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
		try {
			c.setTime( sdf.parse(date)  );
			return c.get(Calendar.MONTH)+1;
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			return -1;
		}
	}
	public static int getDay(String date) {
		Calendar c = Calendar.getInstance();
		SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
		try {
			c.setTime( sdf.parse(date)  );
			return c.get(Calendar.DAY_OF_MONTH);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			return -1;
		}
	}
	
	public boolean isFuture(Date date) {
		return date.after(new Date());
	}
	
	public boolean isFuture(String date, String format) throws ParseException {
		SimpleDateFormat sdf = new SimpleDateFormat( format );
		Date inputDate = sdf.parse(date);
		return inputDate.after(  new Date() );
	}
	
	public boolean isPast(Date date) {
		return date.before(new Date());
	}
	public boolean isPast(String date, String format) throws ParseException {
		SimpleDateFormat sdf = new SimpleDateFormat( format );
		Date inputDate = sdf.parse(date);
		return inputDate.before(  new Date() );
	}
	

}
