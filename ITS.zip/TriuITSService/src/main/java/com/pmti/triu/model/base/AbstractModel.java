package com.pmti.triu.model.base;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.MappedSuperclass;

@MappedSuperclass
public class AbstractModel implements Serializable {
	
	

	@Column(name="DATE_CREATED DATE")
	private Date createdDate;
	
	@Column(name="CREATED_BY")
	private String createdBy;
	
	@Column(name="DATE_MODIFIED")
	private Date lastModifiedDate;
	
	@Column(name="MODIFIED_BY")
	private String lastModifieidBy;
	

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getLastModifiedDate() {
		return lastModifiedDate;
	}

	public void setLastModifiedDate(Date lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public String getLastModifieidBy() {
		return lastModifieidBy;
	}

	public void setLastModifieidBy(String lastModifieidBy) {
		this.lastModifieidBy = lastModifieidBy;
	}

	
}
