package com.pmti.triu.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.pmti.triu.model.base.AbstractModel;

@Entity
@Table(name="REG_INDUSTRIES")
public class Industry extends AbstractModel {
	
	@Id
	@Column(name="TIN")
	private String tin;
	
	@Column(name="BRANCH_CODE")
	private String branchCode;
	
	@Column(name="MIT_CODE")
	private String mitCode;
	
	@Column(name="INDTYP_CODE")
	private String indTypeCode;
	
	@Column(name="PROCESS")
	private String process;

	public String getTin() {
		return tin;
	}

	public void setTin(String tin) {
		this.tin = tin;
	}

	public String getBranchCode() {
		return branchCode;
	}

	public void setBranchCode(String branchCode) {
		this.branchCode = branchCode;
	}

	public String getMitCode() {
		return mitCode;
	}

	public void setMitCode(String mitCode) {
		this.mitCode = mitCode;
	}

	public String getIndTypeCode() {
		return indTypeCode;
	}

	public void setIndTypeCode(String indTypeCode) {
		this.indTypeCode = indTypeCode;
	}

	public String getProcess() {
		return process;
	}

	public void setProcess(String process) {
		this.process = process;
	}

	@Override
	public String toString() {
		return "Industry [tin=" + tin + ", branchCode=" + branchCode + ", mitCode=" + mitCode + ", indTypeCode="
				+ indTypeCode + ", process=" + process + ", getCreatedDate()=" + getCreatedDate() + ", getCreatedBy()="
				+ getCreatedBy() + ", getLastModifiedDate()=" + getLastModifiedDate() + ", getLastModifieidBy()="
				+ getLastModifieidBy() + "]";
	}

	public Industry() {
		super();
	}
	
	
	

}
