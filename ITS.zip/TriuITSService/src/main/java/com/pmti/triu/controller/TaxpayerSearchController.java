package com.pmti.triu.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.pmti.triu.model.TaxpayerSearch;
import com.pmti.triu.service.TaxpayerSearchService;

@RestController
@RequestMapping("/api")
@SuppressWarnings("unused")
public class TaxpayerSearchController {
	
	private TaxpayerSearchService taxpayerSearchService;
	
	
	TaxpayerSearchController(TaxpayerSearchService taxpayerSearchService){
		this.taxpayerSearchService = taxpayerSearchService;
	}
	
	@RequestMapping(value="/search",method=RequestMethod.POST, consumes= {"application/json"})
	ResponseEntity<?> search(@RequestBody TaxpayerSearch taxpayerSearch){

		
		
		return this.taxpayerSearchService.search(taxpayerSearch);
	}
	
}
