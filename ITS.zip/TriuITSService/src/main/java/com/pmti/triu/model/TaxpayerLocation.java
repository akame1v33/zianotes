package com.pmti.triu.model;

import java.util.Date;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.pmti.triu.model.base.AbstractModel;
import com.pmti.triu.model.base.Name;

@Entity
@Table(name="REG_TAXPAYER_LOCATIONS")
public class TaxpayerLocation extends AbstractModel  {
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -2911240228372939829L;

	@Id
	@Column(name="TIN")
	private String tin;
	
	@Column(name="BRANCH_CODE")
	private String branchCode;
	
	@Column(name="STATUS_CODE")
	private String statusCode;
	
	@Column(name="COMPUTERIZED_ACCTG")
	private String isComputerized;
		
	@Column(name="RDO_CODE")
	private String rdoCode;
	
	@Column(name="MUN_CODE")
	private String munCode;
	
	@Column(name="DATE_REGISTERED")
	private Date dateRegistered;
	
	@Column(name="CAN_CODE")
	private String cancelCode;
	
	@Column(name="PREV_RDO_CODE")
	private String prevRdoCode;
	
	@Column(name="PREV_MUN_CODE")
	private String prevMunCode;
	
	@Column(name="NEW_RDO_CODE")
	private String newRdoCode;
	
	@Column(name="NEW_MUN_CODE")
	private String newMunCode;
	
	@Column(name="TRANSFER_DATE")
	private Date transferDate;
	
	@Column(name="CANCEL_DATE")
	private Date cancelDate;
	
	@Column(name="CESSATION_DATE")
	private Date cessationDate;
	
	@Embedded
	@AttributeOverrides({
		 @AttributeOverride(name="lastName", 		column = @Column(name="CONTACT_LAST_NAME") ),
		 @AttributeOverride(name="firstName", 		column = @Column(name="CONTACT_FIRST_NAME") ),
		 @AttributeOverride(name="middleName", 		column = @Column(name="CONTACT_MIDDLE_INIT") ),
	})
	private Name contactName;
	
	@Column(name="CONTACT_TEL_NO")
	private String contactTelNo;
	
	@Column(name="PROCESS")
	private String process;
	
	@Column(name="STOCKTAKING_FROM_DATE")
	private Date stockTakingFromDate;
	
	@Column(name="STOCKTAKING_TO_DATE")
	private Date stockTakingToDate;

	@Override
	public String toString() {
		return "TaxpayerLocation [tin=" + tin + ", branchCode=" + branchCode + ", statusCode=" + statusCode
				+ ", isComputerized=" + isComputerized + ", rdoCode=" + rdoCode + ", munCode=" + munCode
				+ ", dateRegistered=" + dateRegistered + ", cancelCode=" + cancelCode + ", prevRdoCode=" + prevRdoCode
				+ ", prevMunCode=" + prevMunCode + ", newRdoCode=" + newRdoCode + ", newMunCode=" + newMunCode
				+ ", transferDate=" + transferDate + ", cancelDate=" + cancelDate + ", cessationDate=" + cessationDate
				+ ", contactName=" + contactName + ", contactTelNo=" + contactTelNo + ", process=" + process
				+ ", stockTakingFromDate=" + stockTakingFromDate + ", stockTakingToDate=" + stockTakingToDate + "]";
	}

	public TaxpayerLocation() {
		super();
	}
	
	
	
	
	
	
}
