package com.pmti.triu.model.base;

import javax.persistence.Embeddable;

@Embeddable
public class Address {
	
	private String substreet;
	
	private String street;
	
	private String barangay;
	
	private String district;
	
	private String city;
	
	private String zipCode;

	@Override
	public String toString() {
		return "\nAddress = {\n\tsubstreet:\t\t" + substreet + ",\n\tstreet:\t\t" + street + ",\n\tbarangay:\t\t"
				+ barangay + ",\n\tdistrict:\t\t" + district + ",\n\tcity:\t\t" + city + ",\n\tzipCode:\t\t" + zipCode
				+ "\n}";
	}

	public String getSubstreet() {
		return substreet;
	}

	public void setSubstreet(String substreet) {
		this.substreet = substreet;
	}

	public String getStreet() {
		return street;
	}

	public void setStreet(String street) {
		this.street = street;
	}

	public String getBarangay() {
		return barangay;
	}

	public void setBarangay(String barangay) {
		this.barangay = barangay;
	}

	public String getDistrict() {
		return district;
	}

	public void setDistrict(String district) {
		this.district = district;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getZipCode() {
		return zipCode;
	}

	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}

	public Address() {
		super();
	}
	
	
}
