package com.pmti.triu.validator;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

public class PhoneValidator implements  ConstraintValidator<Phone, String> {


	private boolean mandatory;
	
	@Override
    public void initialize(Phone isValidBirthdate) {
		this.mandatory	= isValidBirthdate.mandatory();
    }
	
	@Override
	public boolean isValid(String value, ConstraintValidatorContext context) {
		// TODO Auto-generated method stub
		if( mandatory ) {
			if( value == null ) {
				return false;
			}
			if( value.isEmpty() ) {
				return false;
			}
		} else {
			if( value == null ) {
				return true;
			}
		}
		if( value.isEmpty() ) {
			return false;
		}
		
		String regexPatternForNumber = "\\d+";
		String phoneNo = value.trim();
		if( !phoneNo.contains("-")  || !phoneNo.contains("(") || !phoneNo.contains(")") ) {
//			System.out.println("MISSING SPECIAL CHARACTER");
			return false;
		}
		if( phoneNo.length() == 13 ) {
			
			String digitInsideParen = phoneNo.substring(1, 4);
			String next3Digit = phoneNo.substring(5,8);
			String next4Digit = phoneNo.substring(9,13);
//			System.out.println(digitInsideParen);
//			System.out.println(next4Digit);
//			System.out.println(next3Digit);
			if(  digitInsideParen.matches(regexPatternForNumber) && next3Digit.matches(regexPatternForNumber) && next4Digit.matches(regexPatternForNumber)) {
				return true;
			} else {
				return false;
			}
			
		} else if( phoneNo.length() == 12) {
			String digitInsideParen = phoneNo.substring(1, 3);
			String next3Digit = phoneNo.substring(4,7);
			String next4Digit = phoneNo.substring(8,12);
			if(  digitInsideParen.matches(regexPatternForNumber) && next3Digit.matches(regexPatternForNumber) && next4Digit.matches(regexPatternForNumber)) {
				return true;
			} else {
				return false;
			}
		} else {
			return false;
		}
		
	}

}
