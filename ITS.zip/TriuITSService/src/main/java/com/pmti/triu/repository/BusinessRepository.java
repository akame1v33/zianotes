package com.pmti.triu.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.pmti.triu.model.Business;

@Repository
public interface BusinessRepository extends CrudRepository<Business, String> {

}
