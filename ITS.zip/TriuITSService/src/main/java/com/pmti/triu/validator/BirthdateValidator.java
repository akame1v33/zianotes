package com.pmti.triu.validator;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

public class BirthdateValidator implements  ConstraintValidator<IsValidBirthdate, String>  {
	
	private int size;
	private String format;
	private boolean mandatory;
	
	@Override
    public void initialize(IsValidBirthdate isValidBirthdate) {
		this.size 		= isValidBirthdate.size();
		this.format 	= isValidBirthdate.format();
		this.mandatory	= isValidBirthdate.mandatory();
    }
	
	@Override
	public boolean isValid(String birthDate, ConstraintValidatorContext context) {
		System.out.println("Birthdate: "+birthDate);
		if( this.mandatory ) {
			if( birthDate == null) {
				return false;
			}
			if( birthDate.isEmpty() ) {
				return false;
			}
		} else {
			if( birthDate == null) {
				return true;
			}
			if( birthDate.isEmpty() ) {
				return true;
			}
		}
		
		if( birthDate.length() != this.size ) {
			return false;
		}
		SimpleDateFormat sdf = new SimpleDateFormat(this.format);
		sdf.setLenient(false);
		
		try {
			//if not valid, it will throw ParseException
			Date date = sdf.parse(birthDate);
		
		} catch (ParseException e) {
			e.printStackTrace();
			return false;
		}
		
		return true;
	}

}
