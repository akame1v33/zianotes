package com.pmti.triu.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name="REG_TAX_TYPE_DETAILS")
public class TaxtypeDetail implements Serializable {

	/**
	 * 
	 */
	@Transient
	private static final long serialVersionUID = -4860595451645412670L;
	
	@Id
	@Column(name="TIN")
	private String tin;
	
	@Column(name="BRANCH_CODE")
	private String branchCode;
	
	@Column(name="TTYPE_CODE")
	private String taxTypeCode;
	
	@Column(name="CREATED_BY")
	private String createdBy;
	
	@Column(name="DATE_CREATED")
	private Date createdDate;
	
	@Column(name="FIRST_RETRN_SEQ_NUM")
	private int firstReturnSeqNum;
	
	@Column(name="PROCESS")
	private String process;

	public String getTin() {
		return tin;
	}

	public void setTin(String tin) {
		this.tin = tin;
	}

	public String getBranchCode() {
		return branchCode;
	}

	public void setBranchCode(String branchCode) {
		this.branchCode = branchCode;
	}

	public String getTaxTypeCode() {
		return taxTypeCode;
	}

	public void setTaxTypeCode(String taxTypeCode) {
		this.taxTypeCode = taxTypeCode;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public int getFirstReturnSeqNum() {
		return firstReturnSeqNum;
	}

	public void setFirstReturnSeqNum(int firstReturnSeqNum) {
		this.firstReturnSeqNum = firstReturnSeqNum;
	}

	public String getProcess() {
		return process;
	}

	public void setProcess(String process) {
		this.process = process;
	}

	@Override
	public String toString() {
		return "TaxtypeDetail [tin=" + tin + ", branchCode=" + branchCode + ", taxTypeCode=" + taxTypeCode
				+ ", createdBy=" + createdBy + ", createdDate=" + createdDate + ", firstReturnSeqNum="
				+ firstReturnSeqNum + ", process=" + process + ", getClass()=" + getClass() + ", hashCode()="
				+ hashCode() + ", toString()=" + super.toString() + "]";
	}

	public TaxtypeDetail() {
		super();
	}
	
	
}

