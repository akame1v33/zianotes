package com.pmti.triu.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.pmti.triu.model.base.AbstractModel;

@Entity
@Table(name="REG_TAXPAYER_TYPE_DETAILS")
public class TaxpayertypeDetail extends AbstractModel {
	
	@Id
	@Column(name="TIN")
	private String tin;
	
	@Column(name="TPTYPE_CODE")
	private String tpTypeCode;

	public String getTin() {
		return tin;
	}

	public void setTin(String tin) {
		this.tin = tin;
	}

	public String getTpTypeCode() {
		return tpTypeCode;
	}

	public void setTpTypeCode(String tpTypeCode) {
		this.tpTypeCode = tpTypeCode;
	}

	@Override
	public String toString() {
		return "TaxtypeDetail [tin=" + tin + ", tpTypeCode=" + tpTypeCode + ", getCreatedDate()=" + getCreatedDate()
				+ ", getCreatedBy()=" + getCreatedBy() + ", getLastModifiedDate()=" + getLastModifiedDate()
				+ ", getLastModifieidBy()=" + getLastModifieidBy() + "]";
	}

	public TaxpayertypeDetail() {
		super();
	}
	
	
	
}
