package com.pmti.triu.service;

import org.apache.el.stream.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.pmti.triu.model.Business;
import com.pmti.triu.repository.BusinessRepository;


@SuppressWarnings("unused")
@Service
public class RegistrationService {
	
	
	private final BusinessRepository businessRepo;
	
	@Autowired
	RegistrationService(BusinessRepository businessRepo){
		this.businessRepo = businessRepo;
	}
	
	
	public ResponseEntity<?> register(){
	
		return null;
	}
}
