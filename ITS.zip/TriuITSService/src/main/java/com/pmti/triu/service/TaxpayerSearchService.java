package com.pmti.triu.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.pmti.triu.model.TaxpayerSearch;
import com.pmti.triu.util.ResponseUtil;

@Service
public class TaxpayerSearchService {

	
	
	
	@Autowired
	TaxpayerSearchService() {
		
	}
	
	private ResponseEntity<?> validate(TaxpayerSearch taxpayerSearch) {
//		String tinWithBranch = 
		
		
		return ResponseUtil.ok();
	}
	
	public ResponseEntity<?> search(TaxpayerSearch taxpayerSearch){
		
		
		
		return ResponseUtil.ok();
	}
}
