package com.pmti.triu.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.pmti.triu.model.base.AbstractModel;
import com.pmti.triu.model.base.Name;

@Entity
@Table(name="REG_TAXPAYERS")
public class Taxpayer extends AbstractModel implements Serializable {
	
	/**
	 * 
	 */
	@Transient
	private static final long serialVersionUID = -5565331134552773821L;

	@Id
	@Column(name="TIN")
	private String tin;
	
	@Column(name="STATUS_CODE")
	private String statusCode;
	
	@Column(name="TPCLSF_TYPE_CODE")
	private String tpClsfTypeCode;
	
	@Column(name="DATE_REGISTERED")
	private Date dateRegistered;
	
	@Column(name="RESTRICTED")
	private boolean isRestricted;

	@Column(name="TPGROUP_TYPE_CODE")
	private String tpGroupTypeCode;
	
	@Column(name="MIT_CODE")
	private String mitCode;
	
	@Column(name="INDTYP_CODE")
	private String indTypeCode;
	
	@Column(name="EXTYPE_CODE")
	private String exTypeCode;
	
	@Column(name="CITZN_CODE")
	private String citizenCode;
	
	@Column(name="REGISTERED_NAME")
	private String registeredName;
	
	@Column(name="NATIONALITY_CODE")
	private String nationalityCode;
	
	@Column(name="ORGANIZATION_DATE")
	private Date organizationDate;
	
	@Embedded
	@AttributeOverrides({
		 @AttributeOverride(name="lastName", 		column = @Column(name="LAST_NAME") ),
		 @AttributeOverride(name="firstName", 		column = @Column(name="FIRST_NAME") ),
		 @AttributeOverride(name="middleName", 		column = @Column(name="MIDDLE_NAME") ),
	})
	private Name taxpayerName;
	
	@Column(name="RESIDENCY_CODE")
	private String residencyCode;
	
	@Column(name="SPOUSE_TIN")
	private String spouseTin;
	
	@Embedded
	@AttributeOverrides({
		 @AttributeOverride(name="lastName", 		column = @Column(name="SPOUSE_LAST_NAME") ),
		 @AttributeOverride(name="firstName", 		column = @Column(name="SPOUSE_FIRST_NAME") ),
		 @AttributeOverride(name="middleName", 		column = @Column(name="SPOUSE_MIDDLE_NAME") ),
	})
	private Name spouseName;
	
	@Column(name="BIRTH_DATE")
	private Date birthDate;
	
	@Column(name="CIVIL_STATUS")
	private String civilStatus;
	
	@Column(name="SEX")
	private String gender;

	@Column(name="CLAIM_FLAG")
	private String claimFlag;
	
	@Column(name="PROCESS")
	private String process;
	
	@Column(name="LAST_BRANCH_CODE")
	private String lastBranchCode;
	
	@Column(name="LAST_AUDITED_DATE")
	private Date lastAuditedDate;
	
	
	@Column(name="TP_SEGMENT_CODE")
	private String tpSegmentCode;
	
	@Column(name="SEC_NUMBER")
	private String secNumber;
	
	
	public String getTin() {
		return tin;
	}


	public void setTin(String tin) {
		this.tin = tin;
	}


	public String getStatusCode() {
		return statusCode;
	}


	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}


	public String getTpClsfTypeCode() {
		return tpClsfTypeCode;
	}


	public void setTpClsfTypeCode(String tpClsfTypeCode) {
		this.tpClsfTypeCode = tpClsfTypeCode;
	}


	public Date getDateRegistered() {
		return dateRegistered;
	}


	public void setDateRegistered(Date dateRegistered) {
		this.dateRegistered = dateRegistered;
	}


	public boolean isRestricted() {
		return isRestricted;
	}


	public void setRestricted(boolean isRestricted) {
		this.isRestricted = isRestricted;
	}




	public String getTpGroupTypeCode() {
		return tpGroupTypeCode;
	}


	public void setTpGroupTypeCode(String tpGroupTypeCode) {
		this.tpGroupTypeCode = tpGroupTypeCode;
	}


	public String getMitCode() {
		return mitCode;
	}


	public void setMitCode(String mitCode) {
		this.mitCode = mitCode;
	}


	public String getIndTypeCode() {
		return indTypeCode;
	}


	public void setIndTypeCode(String indTypeCode) {
		this.indTypeCode = indTypeCode;
	}


	public String getExTypeCode() {
		return exTypeCode;
	}


	public void setExTypeCode(String exTypeCode) {
		this.exTypeCode = exTypeCode;
	}


	public String getCitizenCode() {
		return citizenCode;
	}


	public void setCitizenCode(String citizenCode) {
		this.citizenCode = citizenCode;
	}


	public String getRegisteredName() {
		return registeredName;
	}


	public void setRegisteredName(String registeredName) {
		this.registeredName = registeredName;
	}


	public String getNationalityCode() {
		return nationalityCode;
	}


	public void setNationalityCode(String nationalityCode) {
		this.nationalityCode = nationalityCode;
	}


	public Date getOrganizationDate() {
		return organizationDate;
	}


	public void setOrganizationDate(Date organizationDate) {
		this.organizationDate = organizationDate;
	}


	public Name getTaxpayerName() {
		return taxpayerName;
	}


	public void setTaxpayerName(Name taxpayerName) {
		this.taxpayerName = taxpayerName;
	}


	public String getResidencyCode() {
		return residencyCode;
	}


	public void setResidencyCode(String residencyCode) {
		this.residencyCode = residencyCode;
	}


	public String getSpouseTin() {
		return spouseTin;
	}


	public void setSpouseTin(String spouseTin) {
		this.spouseTin = spouseTin;
	}


	public Name getSpouseName() {
		return spouseName;
	}


	public void setSpouseName(Name spouseName) {
		this.spouseName = spouseName;
	}


	public Date getBirthDate() {
		return birthDate;
	}


	public void setBirthDate(Date birthDate) {
		this.birthDate = birthDate;
	}


	public String getCivilStatus() {
		return civilStatus;
	}


	public void setCivilStatus(String civilStatus) {
		this.civilStatus = civilStatus;
	}


	public String getGender() {
		return gender;
	}


	public void setGender(String gender) {
		this.gender = gender;
	}


	public String getClaimFlag() {
		return claimFlag;
	}


	public void setClaimFlag(String claimFlag) {
		this.claimFlag = claimFlag;
	}


	public String getProcess() {
		return process;
	}


	public void setProcess(String process) {
		this.process = process;
	}


	public String getLastBranchCode() {
		return lastBranchCode;
	}


	public void setLastBranchCode(String lastBranchCode) {
		this.lastBranchCode = lastBranchCode;
	}


	public Date getLastAuditedDate() {
		return lastAuditedDate;
	}


	public void setLastAuditedDate(Date lastAuditedDate) {
		this.lastAuditedDate = lastAuditedDate;
	}


	public String getTpSegmentCode() {
		return tpSegmentCode;
	}


	public void setTpSegmentCode(String tpSegmentCode) {
		this.tpSegmentCode = tpSegmentCode;
	}


	public String getSecNumber() {
		return secNumber;
	}


	public void setSecNumber(String secNumber) {
		this.secNumber = secNumber;
	}

	@Override
	public String toString() {
		return "Taxpayer [tin=" + tin + ", statusCode=" + statusCode + ", tpClsfTypeCode=" + tpClsfTypeCode
				+ ", dateRegistered=" + dateRegistered + ", isRestricted=" + isRestricted + ", tpGroupTypeCode="
				+ tpGroupTypeCode + ", mitCode=" + mitCode + ", indTypeCode=" + indTypeCode + ", exTypeCode="
				+ exTypeCode + ", citizenCode=" + citizenCode + ", registeredName=" + registeredName
				+ ", nationalityCode=" + nationalityCode + ", organizationDate=" + organizationDate + ", taxpayerName="
				+ taxpayerName + ", residencyCode=" + residencyCode + ", spouseTin=" + spouseTin + ", spouseName="
				+ spouseName + ", birthDate=" + birthDate + ", civilStatus=" + civilStatus + ", gender=" + gender
				+ ", claimFlag=" + claimFlag + ", process=" + process + ", lastBranchCode=" + lastBranchCode
				+ ", lastAuditedDate=" + lastAuditedDate + ", tpSegmentCode=" + tpSegmentCode + ", secNumber="
				+ secNumber + ", getCreatedDate()=" + getCreatedDate() + ", getCreatedBy()=" + getCreatedBy()
				+ ", getLastModifiedDate()=" + getLastModifiedDate() + ", getLastModifieidBy()=" + getLastModifieidBy()
				+ "]";
	}


	public Taxpayer() {
		super();
	}
	
	
	
	
}
