package com.pmti.triu.util;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

public final class ResponseUtil {
	
	private ResponseUtil() {}
	
	ResponseEntity<?> response(){
		
		return new ResponseEntity<>(HttpStatus.OK);
//		return 
	}
	
	
	public static ResponseEntity<?> ok(){
		return new ResponseEntity<>(HttpStatus.OK);
	}
}
