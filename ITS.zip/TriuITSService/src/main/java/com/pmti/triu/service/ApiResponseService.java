package com.pmti.triu.service;

import org.springframework.stereotype.Service;

@Service
public class ApiResponseService {
	
//	public ResponseEntity<?> createResponse(HttpStatus httpStatus, String messageCode, String message, Result result) {
//		APIResponse response = new APIResponse();
//		response.setMessage(message);
//		response.setResponseCode(messageCode);
//		List<Result> results = new ArrayList<Result>();
//		results.add(result);
//		response.setResult(results);
//		return new ResponseEntity<>(response, httpStatus);
//	}
//
//	public ResponseEntity<?> createResponse(HttpStatus httpStatus, String messageCode, String message) {
//		APIResponse response = new APIResponse();
//		response.setMessage(message);
//		response.setResponseCode(messageCode);
//		return new ResponseEntity<>(response, httpStatus);
//	}
//	
//	public ResponseEntity<?> createResponse(Boolean ok,HttpStatus httpStatus) {
//		APIResponse response = new APIResponse();
//
//		return new ResponseEntity<>(ok, httpStatus);
//	}
//
//	public ResponseEntity<?> createResponse(HttpStatus httpStatus, APIResponse apiResponse) {
//		return new ResponseEntity<>(apiResponse, httpStatus);
//	}
//	public ResponseEntity<?> createResponse(HttpStatus httpStatus, String messageCode, String message, String moreInfo) {
//		APIResponse response = new APIResponse();
//		response.setMessage(message);
//		response.setResponseCode(messageCode);
//		response.setMoreInfo(moreInfo);
//		
//		return new ResponseEntity<>(response, httpStatus);
//	}
//	
//	public ResponseEntity<?> createResponse(HttpStatus httpStatus, String messageCode, String message, String moreInfo, List<Result> results) {
//		APIResponse response = new APIResponse();
//		response.setMessage(message);
//		response.setResponseCode(messageCode);
//		response.setMoreInfo(moreInfo);
//		
//		response.setResult(results);
//		return new ResponseEntity<>(response, httpStatus);
//	}
//	public ResponseEntity<?> createResponse(HttpStatus httpStatus, String messageCode, String message, String consumerId, String referrenceId) {
//		APIResponse response = new APIResponse();
//		response.setMessage(message);
//		response.setResponseCode(messageCode);
//		List<Result> results = new ArrayList<Result>();
//		Result result = new Result();
//		result.setConsumerId(consumerId);
//		result.setTransId(referrenceId);
//		result.setResponseParam(new ResponseParam());
//		results.add(result);
//		
//		response.setResult(results);
//		return new ResponseEntity<>(response, httpStatus);
//	}
//	
//	
//	public APIResponse createResponse(String messageCode, String message, String consumerId, String referrenceId, ResponseParam responseParam ) {
//		APIResponse response = new APIResponse();
//		response.setMessage(message);
//		response.setResponseCode(messageCode);
//		List<Result> results = new ArrayList<Result>();
//		Result result = new Result();
//		result.setConsumerId(consumerId);
//		result.setTransId(referrenceId);
//		result.setResponseParam( responseParam );
//		results.add(result);
//		
//		response.setResult(results);
//		return response;
//	}
//	
	
	

}
