package com.pmti.triu.repository;

import org.springframework.stereotype.Repository;

@Repository
public class TaxpayerRepository {
	
	
}
