package com.pmti.triu.model;



import java.sql.Timestamp;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.pmti.triu.util.DateUtil;

@JsonInclude(Include.NON_NULL)
//@JsonPropertyOrder({"responseCode","message","paramField","paramType","moreInfo"})
public class ResponseModel {
	
	
	private String responseCode;
	private String message;
	
	@JsonFormat(pattern="yyyy-MM-dd HH:mm:ss", timezone = "Asia/Manila")
	private Timestamp transDate = DateUtil.getTimestamp();
	
//	private List<>
}
