package com.reflection;

import java.io.Serializable;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.regex.Pattern;

import com.annotation.Def;
import com.annotation.Defaultable;
import com.annotation.Defaultable.Default;
import com.listener.AddListener;

public class ReflectionApp implements AddListener{
	
	
	public static void main(String args[]) throws IllegalAccessException, IllegalArgumentException, InvocationTargetException, InstantiationException, NoSuchMethodException, SecurityException {
		
//		ReflectionApp rApp = new ReflectionApp();
		
//		List<Integer> intList = Arrays.asList(1,2,3,4,5,6,78);
//		List<String> stringList = Arrays.asList("kirito","wew","wa","aw");
//		List<Object> objectList = Arrays.asList("AHAHAHA","object");
//		List<Number> numberList = Arrays.asList(1,4123123,2);
//
//		ReflectionApp.lowerBounded(objectList);
//		
		
		
		
		List<Student> students = Arrays.asList(
				new Student(1,"Fujitora",99,"SD"),
				new Student(2,"Kizaru",45,"SD"),
				new Student(3,"Aokiji",55,"SD"),
				new Student(4,"ZAkainu",70,"SD")
		);
		
		
		Optional<Student> maxId = students.stream().max( new Comparator<Student>()  {

			@Override
			public int compare(Student o1, Student o2) {
//				System.out.println(  o1.getName().compareTo(o2.getName()));
				return o2.getName().compareTo(o1.getName());
			}
			
				
		} );
//		students.stream().so
		System.out.println(maxId);
				
			
		
		
//		
//		ReflectionApp.printList(intList);
//		ReflectionApp.printList(stringList);
//		R
//		list.add("texst");
		
	
//		DoggyOwner owner = new DoggyOwner(brownies);
		
	}
	///SAMPLE OF UNBOUNDED # GENERICS
	/*
	 * You can pass any type of list using unbounded type
	 */
	public static void unbounded(List<?> list) {
		System.out.println(list);
//		list.fo
	}
	/*
	 * The keyword extends is used even if the upper bound is an interface rather than a class, as in List<? extends Comparable>.
	 * To set superclass limit
	 * This method will only accept class that inherited that Number class ex. Integer, Decimal, Double, Long
	 */
	public static void upperBounded(List<? extends Number> listOfAnyKindOfNumbers) {
		
	}
	/*
	 * PINAGMULAN
	 * ANCESTOR
	 * 
	 */
	public static void lowerBounded(List<? super Integer> ancestor) {
		
	}
	public static void printList(List<?> list) {
		System.out.println(list);
	}
	
	abstract class Animal {
		private String name;
		
		
		public Animal(String name) {
			super();
			this.name = name;
		}

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}
		
	}
	abstract class AnimalOwner<T extends Animal> {
		protected T pet;
		abstract void touchPet();
	}
	class Doggy extends Animal {
		
		public Doggy(String name) {
			super(name);
			// TODO Auto-generated constructor stub
		}

		public void sit() {
			System.out.println( this.getName() + " is sitting" );
		}
	}
	class DoggyOwner extends AnimalOwner<Doggy> {
		
		DoggyOwner(Doggy doggy) {
			this.pet = doggy;
		}
		
		@Override
		void touchPet() {
			// TODO Auto-generated method stub
			this.pet.sit();
			
		}
		
	}
	
	
	public static <T extends Weapon> void setWeapon(T weapon) {
		weapon.weaponName();
//		System.out.println(  );
	}
	public static void setWeaponPoly(Weapon weapon) {
		weapon.weaponName();
//		System.out.println(  );
	}
	public static <T extends Mammal> void test(T mammal) {
		System.out.println( mammal );
	}
	public static void testPoly(Mammal mammal) {
		
		System.out.println( mammal );
	}
	public <T extends Number> T testGenerics(T test) {
		
		return test;
	}
	@SuppressWarnings("unchecked")
	public <T extends Serializable> T annotationProcess(Class<?> clazz, AddListener listener) throws NoSuchMethodException, SecurityException, NumberFormatException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, InstantiationException {
//		Class<Student> clazz = clazz;
		
		AddListener addListener = listener;
		Object object = clazz.newInstance();
		
		if( clazz.isAnnotationPresent( Defaultable.class ) ) {
			Defaultable defaultable =  clazz.getAnnotation(Defaultable.class);
//			System.out.println( defaultable.lastModified() );
//			System.out.println( defaultable.def() );
			Default def = defaultable.def();
			
			if( def == Default.ON ) {
//				
				
				Field[] fields = clazz.getDeclaredFields();
				
				for (Field field : fields) {
//					System.out.println("Declared Field : "+);
					if( field.isAnnotationPresent( Def.class ) ) {
						
						Def anDef = field.getAnnotation(Def.class);
						String value = anDef.value();
						String fieldName = field.getName();	
						Method m = clazz.getMethod("set"+fieldName.replaceFirst( fieldName.substring(0, 1) , fieldName.substring(0, 1).toUpperCase()), field.getType());
						System.out.println( m.getName() );
						if( addListener != null ) {
							value = (String) addListener.beforeAdd(value);
						}
						
						if( field.getGenericType().toString().equalsIgnoreCase("int") ) {
							m.invoke(object,  Integer.parseInt(value) );
							
						} else {
							m.invoke(object,  value );
						}
					}
				}
				
				
				
//				System.out.println( object.toString() );		
				
				
			}
		}	// if
		
		return (T) clazz.cast(object);
	}

	@Override
	public String beforeAdd(String value) {
		// TODO Auto-generated method stub
//		System.out.println("Before add listener: "+value);
		if( !Pattern.compile("\\s").matcher(value).matches() ) {
			value = value.toUpperCase();
		}
		return value;
	}
}
