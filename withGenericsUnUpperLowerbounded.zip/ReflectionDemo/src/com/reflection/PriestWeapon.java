package com.reflection;

public class PriestWeapon extends Weapon {

	@Override
	void weaponName() {
		// TODO Auto-generated method stub
		System.out.println("Wand");
	}

}
