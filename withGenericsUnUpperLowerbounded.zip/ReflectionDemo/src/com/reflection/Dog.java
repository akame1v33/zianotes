package com.reflection;

public class Dog extends Mammal{

	public Dog(String name, String color) {
		super(name, color);
	}

}
