package com.reflection;

public abstract class Weapon {
		
	abstract void weaponName();
}
