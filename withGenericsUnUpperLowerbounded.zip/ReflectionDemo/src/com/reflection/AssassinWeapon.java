package com.reflection;

public class AssassinWeapon extends Weapon {

	@Override
	void weaponName() {
		// TODO Auto-generated method stub
		System.out.println("Katar");
	}
	
	

}
