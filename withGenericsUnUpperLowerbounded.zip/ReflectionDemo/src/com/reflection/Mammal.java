package com.reflection;

public abstract class Mammal {
	private String name;
	private String color;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getColor() {
		return color;
	}
	public void setColor(String color) {
		this.color = color;
	}
	
//	
	public Mammal(String name, String color) {
		super();
		this.name = name;
		this.color = color;
	}
	@Override
	public String toString() {
		return "\nMammal = {\n\tname:\t\t" + name + ",\n\tcolor:\t\t" + color + "\n}";
	}
	
	
	
}
